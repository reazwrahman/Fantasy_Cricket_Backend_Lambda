#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 13 16:32:31 2022

@author: Reaz
"""

## scorecard generator module: generates scorecard for batting and bowling