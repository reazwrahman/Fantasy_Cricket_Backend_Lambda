#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 14 11:50:40 2022

@author: Reaz
"""

TestDict= {  
    
    'test1':{
             'squad_url':'https://www.espncricinfo.com/series/the-ashes-2021-22-1263452/australia-vs-england-5th-test-1263466/match-playing-xi',
             'score_url':'https://www.espncricinfo.com/series/the-ashes-2021-22-1263452/australia-vs-england-5th-test-1263466/full-scorecard'
        
            }, 
    
    'test2':{
             'squad_url':'https://www.espncricinfo.com/series/icc-under-19-world-cup-2021-22-1289790/west-indies-under-19s-vs-australia-under-19s-1st-match-group-d-1289793/match-playing-xi',
             'score_url':'https://www.espncricinfo.com/series/icc-under-19-world-cup-2021-22-1289790/west-indies-under-19s-vs-australia-under-19s-1st-match-group-d-1289793/full-scorecard'
        
            }, 
    
    'test3':{
             'squad_url':'https://www.espncricinfo.com/series/icc-under-19-world-cup-2021-22-1289790/scotland-under-19s-vs-sri-lanka-under-19s-2nd-match-group-d-1289794/match-playing-xi',
             'score_url':'https://www.espncricinfo.com/series/icc-under-19-world-cup-2021-22-1289790/scotland-under-19s-vs-sri-lanka-under-19s-2nd-match-group-d-1289794/full-scorecard'
        
            }, 
    
    'test4':{
             'squad_url':'https://www.espncricinfo.com/series/ireland-in-usa-and-west-indies-2021-22-1291182/west-indies-vs-ireland-2nd-odi-1277086/match-playing-xi',
             'score_url':'https://www.espncricinfo.com/series/ireland-in-usa-and-west-indies-2021-22-1291182/west-indies-vs-ireland-2nd-odi-1277086/full-scorecard'
        
            }, 
    
    'test5':{
             'squad_url':'https://www.espncricinfo.com/series/big-bash-league-2021-22-1269637/adelaide-strikers-vs-perth-scorchers-47th-match-1269686/match-playing-xi',
             'score_url':'https://www.espncricinfo.com/series/big-bash-league-2021-22-1269637/adelaide-strikers-vs-perth-scorchers-47th-match-1269686/full-scorecard'
        
            }, 
    
    'test6':{
              'squad_url':'https://www.espncricinfo.com/series/the-ashes-2021-22-1263452/australia-vs-england-5th-test-1263466/match-playing-xi',
              'score_url':'https://www.espncricinfo.com/series/the-ashes-2021-22-1263452/australia-vs-england-5th-test-1263466/full-scorecard'
        
            }, 
    
    'test7':{
              'squad_url':'https://www.espncricinfo.com/series/bangladesh-in-new-zealand-2021-22-1288977/new-zealand-vs-bangladesh-1st-test-1288979/match-playing-xi',
              'score_url':'https://www.espncricinfo.com/series/bangladesh-in-new-zealand-2021-22-1288977/new-zealand-vs-bangladesh-1st-test-1288979/full-scorecard'
        
            },  
    
    'test8':{
              'squad_url':'https://www.espncricinfo.com/series/ireland-in-usa-and-west-indies-2021-22-1291182/west-indies-vs-ireland-3rd-odi-1277087/match-squads',
              'score_url':'https://www.espncricinfo.com/series/ireland-in-usa-and-west-indies-2021-22-1291182/west-indies-vs-ireland-3rd-odi-1277087/full-scorecard'
        
            }, 
    
    'test9':{
              'squad_url':'https://www.espncricinfo.com/series/legends-league-cricket-2021-22-1298090/world-giants-vs-asia-lions-5th-match-1298100/match-playing-xi',
              'score_url':'https://www.espncricinfo.com/series/legends-league-cricket-2021-22-1298090/world-giants-vs-asia-lions-5th-match-1298100/full-scorecard'
        
            }
    
    
    
    }
