#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 13 16:36:40 2022

@author: Reaz
"""

## Fantasy Batting Points Generator