#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 13 16:42:54 2022

@author: Reaz
"""
## squad generator
